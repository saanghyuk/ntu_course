library(moments)
hist(W4_Q1$x)
hist(W4_Q1$y)

mean(W4_Q1)
sd(W4_Q1$x)
sd(W4_Q1$y)
skewness(W4_Q1)


hist(W4_Q2$x)
hist(W4_Q2$y)
kurtosis(W4_Q2$x)
kurtosis(W4_Q2$y)


#Q4: X
less_than_one_x=sum((W4_Q2$x[abs(W4_Q2$x)<=1]
                     -mean(W4_Q2$x))^4)/length(W4_Q2$x)/sd(W4_Q2$x)^4

more_than_one_x=sum((W4_Q2$x[abs(W4_Q2$x)>1]-mean(W4_Q2$x))^4)/length(W4_Q2$x)/sd(W4_Q2$x)^4

more_than_one_x
less_than_one_x
less_than_one_x+more_than_one_x



#Q4: Y
less_than_one_y=sum((W4_Q2$y[abs(W4_Q2$y)<=1]-mean(W4_Q2$y))^4)/length(W4_Q2$y)/sd(W4_Q2$y)^4
more_than_one_y=sum((W4_Q2$y[abs(W4_Q2$y)>1]-mean(W4_Q2$y))^4)/length(W4_Q2$y)/sd(W4_Q2$y)^4
more_than_one_y
less_than_one_y
less_than_one_y+more_than_one_y



