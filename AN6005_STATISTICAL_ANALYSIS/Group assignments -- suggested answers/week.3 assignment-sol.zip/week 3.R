# ice-cream example: 
# P(X=1)=0.5, P(X=2)=0.4, P(x=3)=0.1

n=1000
#create a placeholder for n obs as the output
output=rep(0,n)

for(i in 1:n){
  spin=runif(1)
  if(spin<0.5){
    output[i]=1
  }
  else if(spin<0.9){
    output[i]=2
  }
  else {
    output[i]=3
  }
}
output
table(output)

# PS: the above results can be similarly achieved by:  
sample(c(1,2,3),n,replace=TRUE,prob=c(.5,.4,.1))

###################
# Question 1
# From Tutorial Q1(c), we know that the pmf if P(X=0)=1/3, P(X=1)=2/3
# Thus, the ice-cream codes apply

n=1000
#create a placeholder for n obs as the output
output=rep(0,n)

for(i in 1:n){
  spin=runif(1)
  if(spin<1/3){
    output[i]=0
    }
  else {
    output[i]=1
  }
}
output
table(output)

# PS: the above results can be similarly achieved by:  
sample(c(0,1),n,replace=TRUE,prob=c(1/3,2/3))

###################
# Question 2
# To simulate N(0,1) using inverse transform, we first "spin" the wheel using runif.
# then we use the inverse cdf of a normal distribution to get the obs.


n=1000
#create a placeholder for n obs as the output
output=rep(0,n)

for(i in 1:n){
 output[i]=qnorm(runif(1)) 
}

# PS: the above results can be similarly achieved by:  
rnorm(1000,0,1)

###################
# Question 3
# The distribution is a mixture of a half-normal and a uniform.
# for x<0, the pdf is a standard normal. For x>0,the pdf is a U(-1,1) 
# note that F(X=0)=0.5, as the standard normal dist is symmetric @ x=0.

#pdf plot
curve(dnorm(x,mean=0,sd=1), col="red",  from=-3, to=0,xlim=c(-3,3),ylim=c(0,1 ))
lines(c(0,1),c(.5,.5),col="red")


n=1000
#create a placeholder for n obs as the output
output=rep(0,n)

for(i in 1:n){
  spin=runif(1)
  # for F(x)<0.5, we know the X<0 ans should be taken from a std normal dist.
  if(spin<0.5){
  output[i]=qnorm(spin) 
  }
  else {
    output[i]=qunif(spin,-1,1) 
  }
}

hist(output)

#####################################
###########the A/R algorithm#########
# plots
curve(dnorm(x,mean=0,sd=1), col="red",  xlim=c(-3,3),ylim=c(0,1 ))
curve(dunif(x,-1,1),   add=TRUE)
curve(dnorm(x,mean=0,sd=1)*2.5, col="blue",  xlim=c(-3,3),ylim=c(0,2),lty=2,add=TRUE)
curve(dnorm(x,mean=0,sd=1)*3.5, col="blue",  xlim=c(-3,3),ylim=c(0,2),lty=2,add=TRUE)
 
#########
n=10000
output=rep(0,n)
acceptance=0
count=0
c=2.5

  while (acceptance<=n) {
    #Step 1: generate an observation from the candidate distribution 2.5*N(0,1)
    X=rnorm(1)
    #Step 2: u(0,1)
    U=runif(1)
    #Step 3: acceptance-rejection
     if(U<dunif(X,-1,1)/(dnorm(X,0,1)*c)){
       acceptance=acceptance+1
       output[acceptance]=X
     }
    count=count+1
  }
  
  hist(output)
  # this is the ratio in which you accepted the proposed observations from N(0,1)
  # only < 0.3, not high, but expectable as the two distributions are not similar in shape.
  n/count
 
  #notice that the rate will drop (take longer to generate 10000 observations), if you choose
  # a larger c value--as this will make the two distributions more dissimilar. 
     
  
## applying AR to the ice-cream example ###############
# P(X=1)=0.5, P(X=2)=0.4, P(x=3)=0.1
## the candidate distribution must have positive probabilities at 1, 2, and 3.
## simplest choose is a uniform P(X=1)=1/3,P(X=2)=1/3,P(X=3)=1/3.
## as such, we can use c=2 as the scaling constant.
## --> (1/3)*2>0.5,  (1/3)*2>0.4, and (1/3)*2>0.1
  
  n=10000
  output=rep(0,n)
   
  acceptance=0
  count=0
  c=2
  
  target=data.frame(X=c(1,2,3),probability=c(0.5,0.4,0.1))
  candidate=data.frame(X=c(1,2,3),probability=c(1/3,1/3,1/3))
  
  while (acceptance<=n) {
    #Step 1: generate an observation from the candidate distribution  
    X1=sample(c(1,2,3),1,replace=TRUE,prob=candidate$probability)
    #Step 2: u(0,1)
    U=runif(1)
    #Step 3: acceptance-rejection
    if(U<target$probability[target$X==X1]/(candidate$probability[candidate$X==X1]*c)){
      acceptance=acceptance+1
      output[acceptance]=X1
    }
    count=count+1
  }
  
  hist(output)
  table(output)
  
  
  